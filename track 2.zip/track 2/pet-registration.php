<?php
session_start();
 
// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your MySQL password if set
$dbname = "user_db";
 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
// Initialize or get existing registered pets array from session
$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];
$editIndex = isset($_GET['editIndex']) ? intval($_GET['editIndex']) : null;
$editPet = $editIndex !== null && isset($registeredPets[$editIndex]) ? $registeredPets[$editIndex] : null;
 
// Process registration form, delete, and update requests
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["deleteIndex"]) && is_numeric($_POST["deleteIndex"])) {
        $deleteIndex = $_POST["deleteIndex"];
        if (isset($registeredPets[$deleteIndex])) {
            $petToDelete = $registeredPets[$deleteIndex];
            $stmt = $conn->prepare("DELETE FROM pets WHERE petName = ? AND petAge = ? AND ownerName = ?");
            $stmt->bind_param("sis", $petToDelete['petName'], $petToDelete['petAge'], $petToDelete['ownerName']);
            if ($stmt->execute()) {
                unset($registeredPets[$deleteIndex]);
                $registeredPets = array_values($registeredPets);
                $_SESSION["registeredPets"] = $registeredPets;
                header("Location: " . $_SERVER["PHP_SELF"]);
                exit();
            } else {
                echo "Error deleting pet: " . $stmt->error;
            }
            $stmt->close();
        }
    } elseif (isset($_POST["updateIndex"]) && is_numeric($_POST["updateIndex"])) {
        $updateIndex = $_POST["updateIndex"];
        if (isset($registeredPets[$updateIndex])) {
            $updatedPet = [
                "petName" => $_POST["petName"],
                "petAge" => $_POST["petAge"],
                "ownerName" => $_POST["ownerName"]
            ];
            $oldPet = $registeredPets[$updateIndex];
            $stmt = $conn->prepare("UPDATE pets SET petName = ?, petAge = ?, ownerName = ? WHERE petName = ? AND petAge = ? AND ownerName = ?");
            $stmt->bind_param("sissss", $updatedPet['petName'], $updatedPet['petAge'], $updatedPet['ownerName'], $oldPet['petName'], $oldPet['petAge'], $oldPet['ownerName']);
            if ($stmt->execute()) {
                $registeredPets[$updateIndex] = $updatedPet;
                $_SESSION["registeredPets"] = $registeredPets;
                header("Location: " . $_SERVER["PHP_SELF"]);
                exit();
            } else {
                echo "Error updating pet: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        // Add new pet
        $newPet = [
            "petName" => $_POST["petName"],
            "petAge" => $_POST["petAge"],
            "ownerName" => $_POST["ownerName"]
        ];
        $stmt = $conn->prepare("INSERT INTO pets (petName, petAge, ownerName) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $newPet['petName'], $newPet['petAge'], $newPet['ownerName']);
        if ($stmt->execute()) {
            $newPet['id'] = $conn->insert_id; // Get the inserted pet's ID
            $registeredPets[] = $newPet;
            $_SESSION["registeredPets"] = $registeredPets;
            header("Location: " . $_SERVER["PHP_SELF"]);
            exit();
        } else {
            echo "Error inserting new pet: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Registration</title>
    <link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0px;
            position: relative;
            background-color: #E7FBE6;
        }
 
        .main-content {
            flex: 1;
            padding: 20px;
            display: flex;
            gap: 1px;
            justify-content: center;            
            max-width: 1200px;
            box-sizing: border-box;
            margin: 0 auto;            
            position: relative;
            align-items: center;                
            height: 100vh;                      
            padding: 20px;          
        }
       
        .form {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 400px;
            box-sizing: border-box;
        }
 
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
            width: 100%;
            margin-bottom: 10px;
        }
 
        label {
            font-weight: bold;
            margin-bottom: 2px;
            margin-top: 10px;
        }
 
        input[type="text"],
        input[type="number"] {
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ccc;
            font-size: 14px;
            box-sizing: border-box;
            background-color: #d8e6e6;
        }
 
        input[type="text"] {
            width: 100%;
        }
 
        input[type="number"] {
            width: 100%;
        }
 
        input[type="submit"] {
            font-size: 16px;
            font-weight: bold;
            width: 100%;
            margin-top: 20px;
            border: solid 1px #03abab;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            color: #fff;
            transition: background-color 0.3s ease, transform 0.3s ease;
            background-color: #088F8F;
         
        }
 
        input[type="submit"]:hover {
            background-color: #13bdbd;
            transform: scale(1.05);
        }
 
        .pet-list {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            max-width: 650px;
            box-sizing: border-box;
            height: 400px;        
            margin-left: auto;
            margin-right: auto;
            margin-top: 20px;
        }
 
        .pet-list h2 {
            margin-bottom: 20px;
            font-size: 1.5rem;
            color: #333;
            text-align: center;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            font-weight: bold;
        }
 
        .pet-list table {
            width: 100%;
            border-collapse: collapse;
        }
 
        .pet-list th, .pet-list td {
            padding: 10px;
           
        }
 
        .pet-list th {
            text-align: left;
            background-color: #fff;
            font-weight: bold;
        }
 
        .pet-list td {
            background-color: #f2f2f2;
        }
 
        .pet-item form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
 
        .delete-btn, .edit-btn {
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            color: #fff;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }
 
        .delete-btn {
            background-color: #e74c3c;
            margin-left: 10px;
        }
 
        .edit-btn {
            background-color: #3498db;
            margin-left: 100px;
        }
 
        .delete-btn:hover {
            background-color: #c0392b;
            transform: scale(1.05);
        }
 
        .edit-btn:hover {
            background-color: #2980b9;
            transform: scale(1.05);
        }
 
        #sidebar {
            width: 20%;
            height: 100vh;
            background-color: white;
        }
 
        #logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            object-fit: contain;
            opacity: 0.4;
            z-index: 0;
        }
        @media (max-width: 700px) {
            span {
                display: none;
            }
 
            #sidebar {
                width: 10%;
                height: 100vh;
                background-color: white;
            }
 
            #logo {
                max-width: 60%;
                max-height: 60%;
                opacity: 0.3;
            }
        }
    </style>
</head>
<body>
    <div class="grid grid-cols-5 h-screen">
        <div id="sidebar">
            <?php include('./sidebar-1.php'); ?>
        </div>
        <div class="col-span-4 size-full relative">
            <img id="logo" src="user/images/logo.png" alt="Logo">
            <div class="main-content">
                <!-- Form for adding/updating pet -->
                <div class="form">
                    <form method="post" id="petForm">
                        <input type="hidden" name="updateIndex" value="<?php echo $editIndex; ?>">
                        <div class="form-group">
                            <label for="petName">PET NAME</label>
                            <input type="text" id="petName" name="petName" value="<?php echo htmlspecialchars($editPet['petName'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="petAge">PET AGE</label>
                            <input type="number" id="petAge" name="petAge" value="<?php echo htmlspecialchars($editPet['petAge'] ?? ''); ?>" required min="1" max="30">
                            <span id="ageError" style="color: red; display: none;">Pet age must be between 1 and 30.</span>
                        </div>
                        <div class="form-group">
                            <label for="ownerName">OWNER NAME</label>
                            <input type="text" id="ownerName" name="ownerName" value="<?php echo htmlspecialchars($editPet['ownerName'] ?? ''); ?>" required>
                        </div>
                        <input type="submit" value="<?php echo $editPet ? 'Update Pet' : 'Add Pet'; ?>">
                    </form>
                </div>
 
                <!-- List of registered pets -->
                <div class="pet-list">
                    <h2>OUR PETS</h2>
                    <?php if (empty($registeredPets)): ?>
                        <p>No pets added.</p>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Pet Name</th>
                                    <th>Pet Age</th>
                                    <th>Owner Name</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registeredPets as $index => $pet): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($pet['petName']); ?></td>
                                        <td><?php echo htmlspecialchars($pet['petAge']); ?></td>
                                        <td><?php echo htmlspecialchars($pet['ownerName']); ?></td>
                                        <td>
                                            <form method="post" style="display: flex; gap: 10px;">
                                                <input type="hidden" name="deleteIndex" value="<?php echo $index; ?>">
                                                <a href="?editIndex=<?php echo $index; ?>" class="edit-btn">Edit</a>
                                                <button type="submit" class="delete-btn">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 
    <script>
        document.getElementById('petForm').addEventListener('submit', function (event) {
            var petAge = document.getElementById('petAge').value;
            var ageError = document.getElementById('ageError');
            if (petAge < 1 || petAge > 30) {
                ageError.style.display = 'inline';
                event.preventDefault(); // Prevent form submission
            } else {
                ageError.style.display = 'none';
            }
        });
    </script>
</body>
</html>